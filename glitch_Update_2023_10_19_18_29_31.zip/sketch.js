function setup() {
  createCanvas(600, 600);
  frameRate(60);

}

function draw() {
  if (mouseIsPressed) {
    background(random (0,255),random (0,255),random (0,255));
    frameRate(24);
  }
  else {
      background(220, 204, 0);    

  }
  fill(255);
  strokeWeight(4);
  stroke(255);


  for (let i = 0; i < 600; i++) {
    let r = random(-50, 50);
    let col = random(r, 255);

    stroke(col*r, col, col);
    line(25 + r, i, 150 + r, i);
    line(mouseX + r, i, 350 + r, i);
    line(425 + r, i, mouseY + r, i); 
    // line(mouseX - r, i, -mouseX - r, i);
  
  
    if(mouseIsPressed) {
      r = 600;
      line(0, 600, 0, 600);
    }
  }
  

}




